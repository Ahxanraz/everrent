<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
     <link rel="stylesheet" href="style.css">
</head>

<body>
 
<!-- header section starts -->

    <header>
        
            <input type="checkbox" name="" id="toggler">
        <label for="toggler" class="fas fa-bars"></label>
<div class="logo">
        <a href=""><img src="image/filogo.png" alt=""></a>
    </div>
        <nav class="navbar">

        <a href="welcome.php">Home</a>
            <a href="myabout.php">About</a>
            <a href="myservice.php">Service</a>
            <a href="mycontact.php">Contact</a>
           
        </nav>
        <div class="icons">
            <a href="logout.php" class="fas fa-left-from-bracket">Logout</a>
        </div>
    </header>

<section>
    
    <h1 class="heading"><span>About</span>Us</h1>
<br>
<div class="myhome">
<div class="aboutheading1">
    <h2>The Perfect Family Home Awaits</h2>
    <p>Welcome to our exceptional family homes, designed with your loved ones in mind. Our spacious and beautifully crafted houses offer the perfect environment for families to thrive. Each home features multiple bedrooms, modern kitchens, and expansive living areas, providing ample space for everyone to enjoy. Our communities are located in safe, family-friendly neighborhoods with excellent schools, parks, and recreational facilities nearby. With a focus on comfort, convenience, and community, our family homes are the ideal choice for those looking to create lasting memories. Discover a place where your family can grow, laugh, and live life to the fullest.
    </p>
</div>
    <div class="aboutimg">
        <img src="image/pic4.png" alt="" style="height: 400px; width: 600px;">
</div>
</div>
<br>
<div class="myhome">
    <div class="aboutheading1">
        <h2>Discover Your Dream Apartment</h2>
    <p>Welcome to our premier apartment community, where comfort and convenience blend seamlessly. Our thoughtfully designed apartments offer a perfect balance of modern amenities and stylish interiors, providing an ideal space to call home. Each unit boasts spacious layouts, contemporary finishes, and ample natural light, creating a warm and inviting atmosphere. Our community features state-of-the-art fitness centers, lush green spaces, and dedicated parking, ensuring a hassle-free lifestyle. Whether you're a young professional, a growing family, or someone seeking a peaceful retreat, our apartments cater to all your needs. Come and experience the perfect place to live, work, and relax.
    </p>
    </div>
        <div class="aboutimg">
            <img src="image/pic10.png" alt="" style="height: 400px; width: 600px;">
    </div>
    </div>
<br>
<div class="myhome">
    <div class="aboutheading1">
        <h2>Experience Unmatched Luxury</h2>
    <p>Step into a world of unparalleled elegance with our luxury homes, where every detail exudes sophistication and comfort. Designed for those who appreciate the finer things in life, our homes feature expansive layouts, premium finishes, and state-of-the-art amenities. From grand living spaces and gourmet kitchens to serene private retreats, each residence is crafted to offer a seamless blend of opulence and functionality. Located in prestigious neighborhoods, our luxury homes provide not just a place to live but a lifestyle of distinction. Indulge in the ultimate living experience and elevate your everyday life to extraordinary heights.
    </p>
    </div>
        <div class="aboutimg">
            <img src="image/pic14.png" alt="" style="height: 400px; width: 600px;">
    </div>
    </div>
<br>
<br>


<h1 class="heading"><span>My</span>Gallery</h1>
<br>
<br>

    <div class="container">
      <div class="mySlides">
        <div class="numbertext">1 / 6</div>
        <img src="image/pic.png" style="width:100%;" height="600px" >
      </div>
    
      <div class="mySlides">
        <div class="numbertext">2 / 6</div>
        <img src="image/pic13.png" style="width:100%" height="600px">
      </div>
    
      <div class="mySlides">
        <div class="numbertext">3 / 6</div>
        <img src="image/pic17.png" style="width:100%" height="600px">
      </div>
        
      <div class="mySlides">
        <div class="numbertext">4 / 6</div>
        <img src="image/pic11.png" style="width:100%" height="600px">
      </div>
    
      <div class="mySlides">
        <div class="numbertext">5 / 6</div>
        <img src="image/pic16.png" style="width:100%" height="600px">
      </div>
        
      <div class="mySlides">
        <div class="numbertext">6 / 6</div>
        <img src="image/pic9.png" style="width:100%" height="600px">
      </div>
        
      <a class="prev" onclick="plusSlides(-1)">❮</a>
      <a class="next" onclick="plusSlides(1)">❯</a>
    
      <div class="caption-container">
        <p id="caption"></p>
      </div>
    
      <div class="row">
        <div class="column">
          <img class="demo cursor" src="image/pic.png" style="width:100%" height="200px" onclick="currentSlide(1)" alt="The Woods">
        </div>
        <div class="column">
          <img class="demo cursor" src="image/pic13.png" style="width:100%" height="200px" onclick="currentSlide(2)" alt="Cinque Terre">
        </div>
        <div class="column">
          <img class="demo cursor" src="image/pic17.png" style="width:100%" height="200px" onclick="currentSlide(3)" alt="Mountains and fjords">
        </div>
        <div class="column">
          <img class="demo cursor" src="image/pic11.png" style="width:100%" height="200px" onclick="currentSlide(4)" alt="Northern Lights">
        </div>
        <div class="column">
          <img class="demo cursor" src="image/pic16.png" style="width:100%" height="200px" onclick="currentSlide(5)" alt="Nature and sunrise">
        </div>    
        <div class="column">
          <img class="demo cursor" src="image/pic9.png" style="width:100%" height="200px" onclick="currentSlide(6)" alt="Snowy Mountains">
        </div>
      </div>
    </div>


</section>
<br>
<footer>
  <div class="footer-container">
      <div class="footer-content">
          <h3>Contact Us</h3>
          <p>Email:info@examle.com</p>
          <p>phone:03xxxxxxxxx</p>
          <p>Address:</p>
      </div>
      <div class="footer-content">
          <h3>Quick Links</h3>
          <ul class="list">
          <li><a href="welcome.php">Home</a></li>
                <li><a href="myabout.php">About</a></li>
                <li><a href="myservice.php">Service</a></li>
                <li><a href="mycontact.php">Contact Us</a></li>
                <li><a href="logout.php">Logout</a></li>
            </ul>
      </div>
      <div class="footer-content">
          <h3>Follow Us</h3>
          <ul class="social-icons">
          <li><a href=""><i class="fab fa-facebook"></i></a></li>
          <li><a href=""><i class="fab fa-twitter"></i></a></li>
          <li><a href=""><i class="fab fa-instagram"></i></a></li>
          <li><a href=""><i class="fab fa-linkedin"></i></a></li>
      </ul>
      </div>
  </div>
  <div class="bottom-bar">
      <p>&copy; 2023 your company . All rights reserved.</p>
  </div>
</footer>

    </body>

    <script type="module" src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.esm.js"></script>
    <script nomodule src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" 
    integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz"
     crossorigin="anonymous"></script>
<script src="script.js"></script>
</html>