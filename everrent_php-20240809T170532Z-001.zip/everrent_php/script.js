// toggle background active
const slideNavigator = name => {
    let slides = document.querySelectorAll('.bg-slide');
    slides.forEach(slide => {
        slide.classList.remove('active');
        if (slide.classList.contains(name)) {
            slide.classList.add('active');
        }
    });
};

// switch background
window.addEventListener('load', () => {
    const slideBtnList = document.querySelectorAll('.slide-btn');
    slideBtnList.forEach(btn => {
        btn.addEventListener('click', function (e){
            e.preventDefault();
            slideBtnList.forEach(el => {
                el.classList.remove('active');
            });
            this.classList.add('active');
            slideNavigator(this.getAttribute('data-target'));
        });
    });
});



let slideIndex = 1;
showSlides(slideIndex);

function plusSlides(n) {
  showSlides(slideIndex += n);
}

function currentSlide(n) {
  showSlides(slideIndex = n);
}

function showSlides(n) {
  let i;
  let slides = document.getElementsByClassName("mySlides");
  let dots = document.getElementsByClassName("demo");
  let captionText = document.getElementById("caption");
  if (n > slides.length) {slideIndex = 1}
  if (n < 1) {slideIndex = slides.length}
  for (i = 0; i < slides.length; i++) {
    slides[i].style.display = "none";
  }
  for (i = 0; i < dots.length; i++) {
    dots[i].className = dots[i].className.replace(" active", "");
  }
  slides[slideIndex-1].style.display = "block";
  dots[slideIndex-1].className += " active";
  captionText.innerHTML = dots[slideIndex-1].alt;
}





gsap.from('.img-2', 1.2 , {opacity:0, y:150, delay:0.6})
    gsap.from('.img-3', 1.2 , {opacity:0, y:150, delay:0.75})
    gsap.from('.img-4', 1.2 , {opacity:0, y:150, delay:.9})
    gsap.from('.img-5', 1.2 , {opacity:0, y:150, delay:1.05})
    gsap.from('.img-6', 1.2 , {opacity:0, y:150, delay:1.20})
    gsap.from('.img-7', 1.2 , {opacity:0, y:150, delay:1.35})
    gsap.from('.h1', 1.2 , {opacity:0, y:-80, delay:1.4})
    gsap.from('h2', 1.2 , {opacity:0, y:-80, delay:1.25})
    
  
  


