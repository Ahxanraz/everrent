<?php
$servername = "localhost";
$username = "root";
$password = "";
$db_name = "everrent_php1";
$conn = mysqli_connect($servername,$username,$password,$db_name);
// if($conn){
//     echo "Connected";
// }else{
    
//     echo "Not Connected";
// }


?>