<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
     <link rel="stylesheet" href="style.css">
</head>

<body>
 
<!-- header section starts -->

    <header>
        
            <input type="checkbox" name="" id="toggler">
        <label for="toggler" class="fas fa-bars"></label>
<div class="logo">
        <a href=""><img src="image/filogo.png" alt=""></a>
    </div>
        <nav class="navbar">

        <a href="home.php">Home</a>
            <a href="about.php">About</a>
            <a href="service.php">Service</a>
            <a href="sign-up.php">Contact</a>
          
        </nav>

        <div class="icons">
    <a href="sign-up.php" class="fas fa-user-plus"></a>
    <a href="login.php" class="fas fa-user"></a>
</div>
    </header>
    
    
        <h1 class="heading"><span>Our</span>Service</h1>
    
    <div class="service">
    <div class="card">
      <img src="image/img1.png" alt="" style="width:100%" height="300px">
      <br><br>
      <h1>Family House</h1>
     <p><button><a href="sign-up.php" class="section-btn">Discover more</a></button></p>
    </div>
    <div class="card">
        <img src="image/img1.png" alt="" style="width:100%" height="300px">
        <br><br>
        <h1>Aparment</h1>
        <p><button><a href="sign-up.php" class="section-btn">Discover more</a></button></p>
      </div>
      <div class="card">
        <img src="image/img1.png" alt="" style="width:100%" height="300px">
        <br><br>
        <h1>Luxury Home</h1>
        <p><button><a href="sign-up.php" class="section-btn">Discover more</a></button></p>
      </div>
</div>


<footer>
    <div class="footer-container">
        <div class="footer-content">
            <h3>Contact Us</h3>
            <p>Email:info@examle.com</p>
            <p>phone:03xxxxxxxxx</p>
            <p>Address:</p>
        </div>
        <div class="footer-content">
            <h3>Quick Links</h3>
            <ul class="list">
            <li><a href="home.php">Home</a></li>
                <li><a href="about.php">About</a></li>
                <li><a href="service.php">Service</a></li>
                <li><a href="contact.php">Contact Us</a></li>
                <li><a href="sign-up.php">Sign-Up</a></li>
            </ul>
        </div>
        <div class="footer-content">
            <h3>Follow Us</h3>
            <ul class="social-icons">
            <li><a href=""><i class="fab fa-facebook"></i></a></li>
            <li><a href=""><i class="fab fa-twitter"></i></a></li>
            <li><a href=""><i class="fab fa-instagram"></i></a></li>
            <li><a href=""><i class="fab fa-linkedin"></i></a></li>
        </ul>
        </div>
    </div>
    <div class="bottom-bar">
        <p>&copy; 2023 your company . All rights reserved.</p>
    </div>
</footer>
</body>
<script type="module" src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.esm.js"></script>
<script nomodule src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" 
integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz"
 crossorigin="anonymous"></script>
<script src="script.js"></script>
</html>