<?php include('connection.php')?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
     <link rel="stylesheet" href="style.css">
</head>

<body class="loginpic">
 
<!-- header section starts -->

 <header>
        
    <input type="checkbox" name="" id="toggler">
<label for="toggler" class="fas fa-bars"></label>
<div class="logo">
<img src="image/filogo.png" alt="">
</div>
<nav class="navbar">

    <a href="home.php">Home</a>
    <a href="about.php">About</a>
    <a href="service.php">Service</a>
    <a href="contact.php">Contact</a>

</nav>
<div class="icons">
    <a href="sign-up.php" class="fas fa-user-plus"></a>
    <a href="login.php" class="fas fa-user"></a>
</div>

</header>
<h1 class="heading"><span>Login</span>Form</h1>

<div class="container">
    <form class="sign-form" method="POST">
       
           
            <label for="email">Email</label>
            <input type="email" name="email" placeholder="Enter Your email" required>
      
            <label for="password">Password</label>
            <input type="password"  name="password" placeholder="Enter Your password" required>
        
        
            <div class="signupbtn">
    
                   <button onclick="myFunction()" name="btn" type="submit">Login</button>
            </div>
      </form>
  </div>
<br><br><br><br><br>
<br><br><br><br><br><br>
 <br><br><br><br><br>


  <footer>
    <div class="footer-container">
        <div class="footer-content">
            <h3>Contact Us</h3>
            <p>Email:info@examle.com</p>
            <p>phone:03xxxxxxxxx</p>
            <p>Address:</p>
        </div>
        <div class="footer-content">
            <h3>Quick Links</h3>
            <ul class="list">
                <li><a href="home.html">Home</a></li>
                <li><a href="about.html">About</a></li>
                <li><a href="service.html">Service</a></li>
                <li><a href="contact.html">Contact Us</a></li>
                <li><a href="sign-up.html">Sign-Up</a></li>
            </ul>
        </div>
        <div class="footer-content">
            <h3>Follow Us</h3>
            <ul class="social-icons">
            <li><a href=""><i class="fab fa-facebook"></i></a></li>
            <li><a href=""><i class="fab fa-twitter"></i></a></li>
            <li><a href=""><i class="fab fa-instagram"></i></a></li>
            <li><a href=""><i class="fab fa-linkedin"></i></a></li>
        </ul>
        </div>
    </div>
    <div class="bottom-bar">
        <p>&copy; 2023 your company . All rights reserved.</p>
    </div>
</footer>


</body>
<script type="module" src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.esm.js"></script>
<script nomodule src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" 
integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz"
 crossorigin="anonymous"></script>
<script src="script.js"></script>
</html>


<?php
if(isset($_POST['btn'])){
 
  $email = $_POST['email'];
  $password = $_POST['password'];

$query ="SELECT * FROM `signup` WHERE Email='$email' AND Password='$password'";
$data = mysqli_query($conn,$query);
$row = mysqli_num_rows($data);

if($data){
  session_start();
  $_SESSION['email'] = $email;
  echo "<script>
  window.location.href='welcome.php';
  </script>";
    }
}

?>



