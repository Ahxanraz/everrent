<?php include('connection.php')?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <!-- <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous"> -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
     <link rel="stylesheet" href="style.css">
</head>

<body>
 
<!-- header section starts -->

    <header>
        
            <input type="checkbox" name="" id="toggler">
        <label for="toggler" class="fas fa-bars"></label>
<div class="logo">
        <img src="image/filogo.png" alt="" >
    </div>
        <nav class="navbar">

            <a href="home.php">Home</a>
            <a href="about.php">About</a>
            <a href="service.php">Service</a>
            <a href="sign-up.php">Contact</a>
            
        </nav>
        <div class="icons">
    <a href="sign-up.php" class="fas fa-user-plus"></a>
    <a href="login.php" class="fas fa-user"></a>
</div>
     
    </header>

<!-- header section ends -->

<!-- home section starts -->   

          <!-- banner -->
    <div class="banner container-fluid">
        <div class="bg-slide slide-1 active">
            <div class="content">
                <h1>Family House</h1>
                <p>"Create lasting memories on a family home that's just right for you. Exploer our listings to find a space where your family can grow and thrive."</p>
            </div>
            <div class="circle bg">
                <img src="image/ani6.png" alt="not working" >
            <div class="circle large">
                <img src="imag/ani6.png" alt="not working" >
            <div class="circle small">
                <img src="image/ani6.png" alt="not working" >
                </div>
            </div>    
            </div>
        </div>
        <div class="bg-slide slide-2">
            <div class="content">
                <h1>Apartment</h1>
                <p>"Experience the convenience and comfort of modern apartment living. Discover your ideal rental apartment with us today."</p>
            </div>
            <div class="circle bg">
                <img src="image/ani1.png" alt="not working" >
            <div class="circle large">
                <img src="image/ani1.png" alt="not working" >
            <div class="circle small">
                <img src="image/ani1.png" alt="not working" >
                </div>
            </div>    
            </div>
        </div>
        <div class="bg-slide slide-3">
            <div class="content">
                <h1>Luxury Home</h1>
                <p>"Indulge in upscale living with our luxury homes. Discover elegance and comfort in your new rental home today."</p>
            </div>
            <div class="circle bg">
                <img src="image/ani2.png" alt="not working" >
            <div class="circle large">
                <img src="image/ani2.png" alt="not working" >
            <div class="circle small">
                <img src="image/ani2.png" alt="not working" >
                </div>
            </div>    
            </div>
        </div>
        <ul class="slide-loader">
            <li><a class="slide-btn" data-target="slide-1">1</a></li>
            <li><a class="slide-btn" data-target="slide-2">2</a></li>
            <li><a class="slide-btn" data-target="slide-3">3</a></li>
        </ul>
        <div class="share">
          <p>Share</p>
          <a href="#"><ion-icon name="share-social-outline"></ion-icon></a>
        </div>
    
        <div class="lead">
          <svg viewBox="0 0 100 100" width="100" height="100">
            <defs>
              <path 
              id="circle"
              d="
              M 50, 50
              m -37,0
              a 37,37 0 1,1 74,0
              a 37,37 0 1,1 -74 ,0"
              />
            </defs>
            <text font-size="17">
              <textpath xlink:href="#circle">"Discover your dream rental home today..."</textpath>
            </text>
            </svg>
            <a href="#" class="move-down">
              <ion-icon name="chevron-down-outline"></ion-icon>
            </a>
        </div>
    

<!-- home section ends -->

<footer style="margin-top:1500px;">
    <div class="footer-container">
        <div class="footer-content">
            <h3>Contact Us</h3>
            <p>Email:info@examle.com</p>
            <p>phone:03xxxxxxxxx</p>
            <p>Address:</p>
        </div>
        <div class="footer-content">
            <h3>Quick Links</h3>
            <ul class="list">
            <li><a href="home.php">Home</a></li>
                <li><a href="about.php">About</a></li>
                <li><a href="service.php">Service</a></li>
                <li><a href="contact.php">Contact Us</a></li>
                <li><a href="sign-up.php">Sign-Up</a></li>
           </ul>
        </div>
        <div class="footer-content">
            <h3>Follow Us</h3>
            <ul class="social-icons">
            <li><a href=""><i class="fab fa-facebook"></i></a></li>
            <li><a href=""><i class="fab fa-twitter"></i></a></li>
            <li><a href=""><i class="fab fa-instagram"></i></a></li>
            <li><a href=""><i class="fab fa-linkedin"></i></a></li>
        </ul>
        </div>
    </div>
    <div class="bottom-bar">
        <p>&copy; 2023 your company . All rights reserved.</p>
    </div>
</footer>






</body>




<script type="module" src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.esm.js"></script>
<script nomodule src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" 
integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz"
 crossorigin="anonymous"></script>
<script src="script.js"></script>
</html>

